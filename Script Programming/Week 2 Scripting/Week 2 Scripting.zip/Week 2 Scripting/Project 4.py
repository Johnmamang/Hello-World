# Project 4 Radius of Sphere Calculation

#Prompt the input for the sphere's radius
radius = float(input("What is the radius of a sphere?"))
pi = 3.14

#Prompt the input for the sphere's radius
sphere_diameter = 2 * radius

#Prompt the input for the sphere's radius
sphere_circumference = 2 * pi * radius

#Prompt the input for the sphere's radius
sphere_surface_area = 4 * pi * radius ** 2

#Prompt the input for the sphere's radius
sphere_volume = (4/3) * pi * radius ** 3

print("Your sphere's diameter is: ", sphere_diameter)
print("Your sphere's circumference is: ", sphere_circumference)
print("Your sphere's surface area is: ", sphere_surface_area)
print("Your sphere's volume is: ", sphere_volume)
